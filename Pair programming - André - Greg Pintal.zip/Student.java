//21/02/24
//pair programming
public class Student{
	private int id;
	private String name;

	Average myAvg = new Average();

	public void setId(int id){
		this.id = id;
	}

	public void setName(String name){
		this.name = name;
	}

	public int getId(){
		return id;
	}

	public String getName(){
		return name;
	}



}

